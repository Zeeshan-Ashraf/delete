from docx2pdf import convert
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class FileConverter:
    @staticmethod
    def convert_to_pdf(input_file_path: str, output_file_path: str) -> bool:
        """
        Convert a given file to PDF format.

        Args:
            input_file_path (str): The path to the input file.
            output_file_path (str): The desired path for the output PDF file.

        Returns:
            bool: True if conversion is successful, False otherwise.
        """
        try:
            logger.info(f"Converting '{input_file_path}' to '{output_file_path}'...")
            convert(input_file_path, output_file_path)  #convert("/Users/zeeshan_ashraf/Desktop/1.docx", "output.pdf")
            
            return True
        except Exception as e:
            logger.error(f"Error converting file: {e}")
            return False