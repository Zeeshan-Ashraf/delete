from __future__ import annotations

from html import unescape
import json
import logging
import os
from pathlib import Path
import re
import time
from typing import Any

from dotenv import load_dotenv
from openai import AzureOpenAI


logger = logging.getLogger(__name__)


class ValidationService:
    DEFAULT_ENV_PATH = Path("../../config/.env")
    DEFAULT_OPENAI_API_VERSION = "2024-10-21"
    DEFAULT_OPENAI_TIMEOUT_SECONDS = 60

    def __init__(
        self,
        rules: dict[str, Any] = None,
        contract_text: dict[str, Any] = None,
        config_file_path: str | Path = DEFAULT_ENV_PATH,
    ) -> None:
        self.rules = rules or {}
        self.contract_text = contract_text or {}

        config_path = Path(config_file_path)
        if not config_path.is_absolute():
            project_app_dir = Path(__file__).resolve().parents[2]
            config_path = (project_app_dir / "config" / ".env")
        self.config_file_path = config_path

        load_dotenv(self.config_file_path, override=False)

        self.azure_openai_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
        self.azure_ai_api_key = os.getenv("AZURE_AI_API_KEY") or os.getenv("AZURE_OPENAI_API_KEY")
        self.azure_openai_api_version = os.getenv(
            "AZURE_OPENAI_API_VERSION",
            self.DEFAULT_OPENAI_API_VERSION,
        )
        self.model_deployment = os.getenv("GPT_4_1_DEPLOYMENT") or os.getenv("AZURE_OPENAI_DEPLOYMENT")

        # Keep the original source object that must be updated in-place.
        self.rules_source: dict[str, Any] = self.rules

        logger.info(
            "ValidationService initialized. rules=%s, contract_contents=%s, env_path=%s",
            len(self.rules_source.get("rules", [])) if isinstance(self.rules_source, dict) else 0,
            len(self.contract_text.get("contents", [])) if isinstance(self.contract_text, dict) else 0,
            self.config_file_path,
        )

    def _get_openai_client(self) -> Any:
        try:
            from openai import AzureOpenAI
        except ImportError as exc:
            raise RuntimeError(
                "The 'openai' package is not installed. Install dependencies from requirements.txt."
            ) from exc

        if not self.azure_openai_endpoint:
            raise ValueError("Missing AZURE_OPENAI_ENDPOINT in environment")
        if not self.azure_ai_api_key:
            raise ValueError("Missing AZURE_AI_API_KEY (or AZURE_OPENAI_API_KEY) in environment")
        if not self.model_deployment:
            raise ValueError("Missing GPT_4_1_DEPLOYMENT (or AZURE_OPENAI_DEPLOYMENT) in environment")

        logger.info(
            "Creating Azure OpenAI client with endpoint=%s, api_version=%s, deployment=%s",
            self.azure_openai_endpoint,
            self.azure_openai_api_version,
            self.model_deployment,
        )
        return AzureOpenAI(
            api_key=self.azure_ai_api_key,
            azure_endpoint=self.azure_openai_endpoint,
            api_version=self.azure_openai_api_version,
            timeout=self.DEFAULT_OPENAI_TIMEOUT_SECONDS,
        )

    @staticmethod
    def _parse_json_response(text: str) -> dict[str, Any]:
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            # Attempt to parse the first JSON object if model wrapped content unexpectedly.
            match = re.search(r"\{.*\}", text, flags=re.DOTALL)
            if not match:
                raise
            return json.loads(match.group(0))

    @staticmethod
    def _is_retryable_error(exc: Exception) -> bool:
        message = str(exc).lower()
        retryable_markers = ["429", "500", "502", "503", "504", "timeout", "temporar", "connection"]
        return any(marker in message for marker in retryable_markers)

    @staticmethod
    def _build_openai_error(exc: Exception) -> RuntimeError:
        return RuntimeError(f"Azure OpenAI validation failed: {exc}")

    @staticmethod
    def _normalize_whitespace(value: str) -> str:
        return re.sub(r"\s+", " ", value).strip()


    @staticmethod
    def _extract_rule_focus(rule: dict[str, Any]) -> str:
        text = f"{rule.get('name', '')} {rule.get('description', '')}".lower()
        tokens = re.findall(r"[a-z0-9_]+", text)
        unique_tokens = []
        for token in tokens:
            if len(token) <= 2:
                continue
            if token in unique_tokens:
                continue
            unique_tokens.append(token)
        return " ".join(unique_tokens[:20])

    def _request_validation_results(self, prompt_payload: dict[str, Any]) -> dict[str, dict[str, str]]:
        client = self._get_openai_client()
        system_prompt = (
            "You validate the contract rules using only the provided contract_evidence. "
            "contract_evidence is extracted field valueString/valueArray."
            "For every rule, align the evidence with rule description and return PASS if clearly satisfied else FAIL. "
            "If FAIL, recommendation must be concrete and actionable. "
            "If PASS, recommendation must be 'Rule satisfied'. "
            "Return strict JSON with this shape: "
            "{\"rules\": [{\"id\": \"001\", \"validation_status\": \"PASS\", \"recommendation\": \"\"}]}"
        )

        last_error: Exception | None = None
        for attempt in range(3):
            try:
                logger.info("Sending validation request to Azure OpenAI. Attempt=%s", attempt + 1)
                
                
                
                
                print("\n\n\n\n#####################################################################\n\n")
                print("message: sys + prompt payload:\n")
                print(json.dumps([
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": json.dumps(prompt_payload, ensure_ascii=True)},
                    ], indent=2))
                print("\n\n\n\n#####################################################################\n\n")
                
                
                
                
                response = client.chat.completions.create(
                    model=self.model_deployment,
                    temperature=0,
                    response_format={"type": "json_object"},
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": json.dumps(prompt_payload, ensure_ascii=True)},
                    ],
                )
                message_content = response.choices[0].message.content or "{}"
                parsed_response = self._parse_json_response(message_content)

                statuses: dict[str, dict[str, str]] = {}
                for item in parsed_response.get("rules", []):
                    rule_id = item.get("id")
                    status = str(item.get("validation_status", "")).upper()
                    recommendation = str(item.get("recommendation", "")).strip()
                    if rule_id and status in {"PASS", "FAIL"}:
                        statuses[rule_id] = {
                            "validation_status": status,
                            "recommendation": recommendation if status == "FAIL" else "",
                        }

                if not statuses:
                    raise ValueError("Azure OpenAI returned an empty validation result set")

                logger.info("Received validation results for %s rule(s)", len(statuses))
                return statuses
            except Exception as exc:
                last_error = exc
                if not self._is_retryable_error(exc) or attempt == 2:
                    break
                sleep_seconds = 2 ** attempt
                logger.warning(
                    "Azure OpenAI validation attempt %s failed: %s. Retrying in %s second(s).",
                    attempt + 1,
                    exc,
                    sleep_seconds,
                )
                time.sleep(sleep_seconds)

        raise self._build_openai_error(last_error or RuntimeError("Unknown Azure OpenAI error")) from last_error


    def _request_validation_results2(self, prompt_payload: dict[str, Any]) -> dict[str, dict[str, str]]:
        client = self._get_openai_client()
        system_prompt = (
            "You validate contract rules using only the provided evidence. "
            "Evidence is extracted field valueString/valueArray."
            "For every rule, align the evidence with rule description and return PASS if clearly satisfied else FAIL. "
            "If FAIL, recommendation must be concrete and actionable. "
            "If PASS, recommendation must be 'Rule satisfied'. "
            "Return strict JSON with this shape: "
            "{\"rules\": [{\"id\": \"001\", \"validation_status\": \"PASS\", \"recommendation\": \"\"}]}"
        )

        last_error: Exception | None = None
        for attempt in range(3):
            try:
                logger.info("Sending validation request to Azure OpenAI. Attempt=%s", attempt + 1)
                
                
                
                
                print("\n\n\n\n#####################################################################\n\n")
                print("message: sys + prompt payload:\n")
                print(json.dumps([
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": json.dumps(prompt_payload, ensure_ascii=True)},
                    ], indent=2))
                print("\n\n\n\n#####################################################################\n\n")
                
                
                
                
                response = client.chat.completions.create(
                    model=self.model_deployment,
                    temperature=0,
                    response_format={"type": "json_object"},
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": json.dumps(prompt_payload, ensure_ascii=True)},
                    ],
                )
                message_content = response.choices[0].message.content or "{}"
                parsed_response = self._parse_json_response(message_content)

                statuses: dict[str, dict[str, str]] = {}
                for item in parsed_response.get("rules", []):
                    rule_id = item.get("id")
                    status = str(item.get("validation_status", "")).upper()
                    recommendation = str(item.get("recommendation", "")).strip()
                    if rule_id and status in {"PASS", "FAIL"}:
                        statuses[rule_id] = {
                            "validation_status": status,
                            "recommendation": recommendation if status == "FAIL" else "",
                        }

                if not statuses:
                    raise ValueError("Azure OpenAI returned an empty validation result set")

                logger.info("Received validation results for %s rule(s)", len(statuses))
                return statuses
            except Exception as exc:
                last_error = exc
                if not self._is_retryable_error(exc) or attempt == 2:
                    break
                sleep_seconds = 2 ** attempt
                logger.warning(
                    "Azure OpenAI validation attempt %s failed: %s. Retrying in %s second(s).",
                    attempt + 1,
                    exc,
                    sleep_seconds,
                )
                time.sleep(sleep_seconds)

        raise self._build_openai_error(last_error or RuntimeError("Unknown Azure OpenAI error")) from last_error


    def validate(self) -> dict[str, Any]:
        logger.info("Starting contract validation")

        if not isinstance(self.rules_source, dict):
            logger.error("rules source is not a dictionary")
            self.rules_source = {"rules": []}

        rules_list = self.rules_source.get("rules", [])
        if not isinstance(rules_list, list):
            logger.error("rules source has invalid 'rules' type: %s", type(rules_list))
            self.rules_source["rules"] = []
            self.rules = self.rules_source
            return self.rules

        logger.info(
            "Prepared contract evidence. extracted_fields=%s",
            len(self.contract_text),
        )

        prompt_payload = {
            "instructions": "Evaluate each rule against the contract evidence only.",
            "rules": [
                {
                    "id": rule.get("id"),
                    "name": rule.get("name"),
                    "description": rule.get("description"),
                    "focus": self._extract_rule_focus(rule),
                }
                for rule in rules_list
                if isinstance(rule, dict) and rule.get("enabled", True)
            ],
            "contract_evidence": self.contract_text,
        }

        llm_results: dict[str, dict[str, str]] = {}
        try:
            llm_results = self._request_validation_results(prompt_payload)
        except Exception as exc:
            logger.exception(
                "LLM validation unavailable, applying local fallback validation only. reason=%s",
                exc,
            )

        for idx, rule in enumerate(rules_list):
            if not isinstance(rule, dict):
                logger.warning("Skipping non-dict rule at index=%s", idx)
                continue

            rule_id = str(rule.get("id", "")).strip()
            if not rule.get("enabled", True):
                logger.info("Skipping disabled rule id=%s", rule_id)
                continue

            result = llm_results.get(rule_id)
            if result:
                validation_status = result.get("validation_status", "FAIL")
                recommendation = result.get("recommendation", "") if validation_status == "FAIL" else ""
                logger.info("Rule id=%s validated by LLM with status=%s", rule_id, validation_status)
            else:
                logger.error("No LLM result for rule id=%s, marking as FAIL")
                validation_status = "FAIL"
                recommendation = "LLM validation failed or unavailable. Please review the rule against the contract manually."

            rule["validation_status"] = validation_status
            rule["recommendation"] = recommendation if validation_status == "FAIL" else ""

        self.rules = self.rules_source
        logger.info("Validation completed. total_rules=%s", len(self.rules_source.get("rules", [])))
        return self.rules
    





























# rules = { 'rules': [ { 'description': 'Description of Service or Contract Works must '
#                               'contain actual service description, not just '
#                               'placeholder instructions usually found in '
#                               'Section 3',
#                'enabled': True,
#                'id': 'SPN-001',
#                'name': 'Service Description Filled',
#                'recommendation': '',
#                'severity': 'P1',
#                'validation_status': 'UNKNOWN'},
#              { 'description': 'The Novartis legal entity name must be '
#                               'explicitly stated — not the placeholder like '
#                               '[INSERT NOVARTIS ENTITY]',
#                'enabled': True,
#                'id': 'SPN-002',
#                'name': 'Novartis Entity Name Filled',
#                'recommendation': '',
#                'severity': 'P1',
#                'validation_status': 'UNKNOWN'},
#              { 'description': 'The supplier legal entity name must be '
#                               'explicitly stated — not a placeholder',
#                'enabled': True,
#                'id': 'SPN-003',
#                'name': 'Supplier Entity Name Filled',
#                'recommendation': '',
#                'severity': 'P1',
#                'validation_status': 'UNKNOWN'},
#              { 'description': 'Statement of Work Startd date must be present — '
#                               'not left blank, usually found in Section 6.',
#                'enabled': True,
#                'id': 'SPN-004',
#                'name': 'Statement of Work Start Date',
#                'recommendation': '',
#                'severity': 'P1',
#                'validation_status': 'UNKNOWN'},
#              { 'description': 'Statement of Work Expiry date must be present — '
#                               'not left blank, usually found in Section 6.',
#                'enabled': True,
#                'id': 'SPN-005',
#                'name': 'Statement of Work Expiry Date',
#                'recommendation': '',
#                'severity': 'P1',
#                'validation_status': 'UNKNOWN'},
#              { 'description': 'must include assumptions and obligations of '
#                               'Novartis — not left blank, usually found in '
#                               'Section 15.',
#                'enabled': True,
#                'id': 'SPN-006',
#                'name': 'Assumptions And Novartis Obligations',
#                'recommendation': '',
#                'severity': 'P1',
#                'validation_status': 'UNKNOWN'}],
#   'schema_id': 'SPIN_SOW',
#   'version': '1.0.0'}


# import json
# data_dict = None
# # Use a 'with' statement for proper file handling
# with open('/Users/zeeshan_ashraf/nova/intel/contract-intel/app/data/extracted/analysis_result_20260322_233016.json', 'r') as file_object:
#     data_dict = json.load(file_object)

# validationService: ValidationService = ValidationService(rules=rules, contract_text=data_dict)
# results = validationService.validate() #returns the same rule with updated keys: validation_status & recommendation
# print(json.dumps(results, indent=2))



























# rules = { 'rules': [ { 'description': 'Description of Service or Contract Works must '
#                               'contain actual service description, not just '
#                               'placeholder instructions usually found in '
#                               'Section 3',
#                'enabled': True,
#                'id': 'SPN-001',
#                'name': 'Service Description Filled',
#                'recommendation': '',
#                'severity': 'P1',
#                'validation_status': 'UNKNOWN'},
#              { 'description': 'The Novartis legal entity name must be '
#                               'explicitly stated — not the placeholder like '
#                               '[INSERT NOVARTIS ENTITY]',
#                'enabled': True,
#                'id': 'SPN-002',
#                'name': 'Novartis Entity Name Filled',
#                'recommendation': '',
#                'severity': 'P1',
#                'validation_status': 'UNKNOWN'},
#              { 'description': 'The supplier legal entity name must be '
#                               'explicitly stated — not a placeholder',
#                'enabled': True,
#                'id': 'SPN-003',
#                'name': 'Supplier Entity Name Filled',
#                'recommendation': '',
#                'severity': 'P1',
#                'validation_status': 'UNKNOWN'},
#              { 'description': 'Statement of Work Startd date must be present — '
#                               'not left blank, usually found in Section 6.',
#                'enabled': True,
#                'id': 'SPN-004',
#                'name': 'Statement of Work Start Date',
#                'recommendation': '',
#                'severity': 'P1',
#                'validation_status': 'UNKNOWN'},
#              { 'description': 'Statement of Work Expiry date must be present — '
#                               'not left blank, usually found in Section 6.',
#                'enabled': True,
#                'id': 'SPN-005',
#                'name': 'Statement of Work Expiry Date',
#                'recommendation': '',
#                'severity': 'P1',
#                'validation_status': 'UNKNOWN'},
#              { 'description': 'must include assumptions and obligations of '
#                               'Novartis — not left blank, usually found in '
#                               'Section 15.',
#                'enabled': True,
#                'id': 'SPN-006',
#                'name': 'Assumptions And Novartis Obligations',
#                'recommendation': '',
#                'severity': 'P1',
#                'validation_status': 'UNKNOWN'}],
#   'schema_id': 'SPIN_SOW',
#   'version': '1.0.0'}


# import json
# data_dict = None
# # Use a 'with' statement for proper file handling
# with open('/Users/zeeshan_ashraf/nova/intel/contract-intel/app/data/extracted/analysis_result_20260322_233016.json', 'r') as file_object:
#     data_dict = json.load(file_object)

# validationService: ValidationService = ValidationService(rules=rules, contract_text=data_dict)
# results = validationService.validate() #returns the same rule with updated keys: validation_status & recommendation
# print(json.dumps(results, indent=2))



rules = {
    "rules": [
        {
            "id": "002",
            "name": "SOX Relevance",
            "description": "SARBANES OXLEY ACT Relevance), Per Clause 27.6(f) must be true",
            "severity": "P1",
            "enabled": True,
        },
        {
            "id":"058",
            "name":"Novartis Entity Name",
            "description":"Full legal name of Novartis party, Must be filled, not left as placeholder",
            "severity":"P1",
            "enabled":True
        }
    ]
}

contract_text = {
    "fields": {
          "SOW_entry_date": {
            "type": "string",
            "valueString": "23 November 2025",
            "spans": [
              {
                "offset": 2378,
                "length": 16
              }
            ],
            "confidence": 0.961,
            "source": "D(2,3.0172,2.1730,4.2291,2.1750,4.2288,2.3436,3.0169,2.3415)"
          },
          "first_party": {
            "type": "string",
            "valueString": "Novartis Pharma AG",
            "spans": [
              {
                "offset": 2412,
                "length": 18
              }
            ],
            "confidence": 0.96,
            "source": "D(2,1.0925,2.4771,2.5601,2.4811,2.5596,2.6530,1.0920,2.6490)"
          },
          "second_party_supplier": {
            "type": "string",
            "valueString": "EPAM Systems, Inc",
            "spans": [
              {
                "offset": 2561,
                "length": 17
              }
            ],
            "confidence": 0.883,
            "source": "D(2,1.0895,3.3108,2.4073,3.3123,2.4071,3.4917,1.0893,3.4902)"
          },
          "StatementOfWorkEffectiveDate": {
            "type": "string",
            "valueString": "24 November 2025",
            "spans": [
              {
                "offset": 5759,
                "length": 16
              }
            ],
            "confidence": 0.934,
            "source": "D(3,4.5151,8.3000,5.6176,8.2956,5.6182,8.4557,4.5157,8.4601)"
          },
          "StatementOfWorkExpiryDate": {
            "type": "string",
            "valueString": "31 December 2026",
            "spans": [
              {
                "offset": 5822,
                "length": 16
              }
            ],
            "confidence": 0.939,
            "source": "D(3,4.3710,8.6087,5.4647,8.6085,5.4647,8.7731,4.3710,8.7733)"
          },
          "SARBANES_OXLEY_ACT_Relevance": {
            "type": "string",
            "valueString": "False",
            "spans": [
              {
                "offset": 5308,
                "length": 15
              }
            ],
            "confidence": 0.698,
            "source": "D(3,1.5555,5.8130,2.5159,5.8130,2.5159,5.9843,1.5555,5.9843)"
          },
          "Assets": {
            "type": "array",
            "valueArray": [
              {
                "type": "object",
                "valueObject": {
                  "Description": {
                    "type": "string",
                    "valueString": "Computers provided and managed by EPAM will be used to access Novartis VDI (Cloud PC) and all work will be done within Novartis environment.",
                    "spans": [
                      {
                        "offset": 9734,
                        "length": 81
                      },
                      {
                        "offset": 9816,
                        "length": 58
                      }
                    ],
                    "confidence": 0.462,
                    "source": "D(5,1.6536,7.5207,7.1744,7.5189,7.1745,7.7014,1.6537,7.7032);D(5,1.5575,7.6992,5.2417,7.7007,5.2416,7.8752,1.5574,7.8736)"
                  }
                }
              },
              {
                "type": "object",
                "valueObject": {
                  "Description": {
                    "type": "string",
                    "valueString": "EPAM MacBooks with Novartis images will be used to access Novartis VPN.",
                    "spans": [
                      {
                        "offset": 9883,
                        "length": 71
                      }
                    ],
                    "confidence": 0.468,
                    "source": "D(5,1.6531,8.0559,6.4239,8.0460,6.4243,8.2228,1.6535,8.2327)"
                  }
                }
              },
              {
                "type": "object",
                "valueObject": {
                  "Description": {
                    "type": "string",
                    "valueString": "Laptops or MacBooks provided by Novartis.",
                    "spans": [
                      {
                        "offset": 9963,
                        "length": 41
                      }
                    ],
                    "confidence": 0.518,
                    "source": "D(5,1.6490,8.4084,4.3983,8.4015,4.3987,8.5777,1.6494,8.5847)"
                  }
                }
              }
            ]
          }
        }
    }



validationService: ValidationService = ValidationService(rules=rules, contract_text=contract_text)
result = validationService.validate()

print("\n\n\n\n#####################################################################\n\n")
print(json.dumps(result, indent=2))














#------------------------------------------------------------------------------------------------------------

client = AzureOpenAI(
            api_key="EiMva6xOm3g942j1Kqy1vdglgyUYcu2DT6E5RgMfeSL8kjaSxk32JQQJ99CCACfhMk5XJ3w3AAAAACOGvEG3",
            azure_endpoint="https://contract-intel-foundry-01.openai.azure.com/",
            api_version="2024-10-21",
            timeout=120,
        )
system_prompt = (
            "You validate the contract rules using only the provided contract_evidence. "
            "contract_evidence is a dictionary containing extracted fields from filled contract document with field name/title as key and filled information as value."
            "For every rule in rules list, check and validate against all the contract_evidence key, value i.e field name/title as key and filled information as value and return PASS if rule clearly satisfied else FAIL. "
            "If FAIL, recommendation must be concrete and actionable. "
            "If PASS, recommendation must be 'Rule satisfied'. "
            "Return strict JSON with this shape: "
            "{\"rules\": [{\"id\": \"001\", \"validation_status\": \"PASS\", \"recommendation\": \"\"}]}"
        )

prompt_payload = {
            "instructions": "Evaluate each rule against the contract_evidence only.",
            "rules": rules.get("rules", []),
            "contract_evidence": contract_text
        }


# response = client.chat.completions.create(
#                     model="gpt-4.1",
#                     temperature=0,
#                     response_format={"type": "json_object"},
#                     messages=[
#                         {"role": "system", "content": system_prompt},
#                         {"role": "user", "content": json.dumps(prompt_payload, ensure_ascii=True)},
#                     ],
#                 )

# import pprint
# pprint.pprint(response.choices[0].message.content)