from __future__ import annotations

from html import unescape
import json
import logging
import os
from pathlib import Path
import re
import time
from typing import Any

from dotenv import load_dotenv


logger = logging.getLogger(__name__)


class ValidationService:
    DEFAULT_ENV_PATH = Path("../../config/.env")
    DEFAULT_OPENAI_API_VERSION = "2024-10-21"
    DEFAULT_OPENAI_TIMEOUT_SECONDS = 60

    def __init__(
        self,
        rules: dict[str, Any] = None,
        contract_text: dict[str, Any] = None,
        config_file_path: str | Path = DEFAULT_ENV_PATH,
    ) -> None:
        self.rules = rules or {}
        self.contract_text = contract_text or {}

        config_path = Path(config_file_path)
        if not config_path.is_absolute():
            project_app_dir = Path(__file__).resolve().parents[2]
            config_path = (project_app_dir / "config" / ".env")
        self.config_file_path = config_path

        load_dotenv(self.config_file_path, override=False)

        self.azure_openai_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
        self.azure_ai_api_key = os.getenv("AZURE_AI_API_KEY") or os.getenv("AZURE_OPENAI_API_KEY")
        self.azure_openai_api_version = os.getenv(
            "AZURE_OPENAI_API_VERSION",
            self.DEFAULT_OPENAI_API_VERSION,
        )
        self.model_deployment = os.getenv("GPT_4_1_DEPLOYMENT") or os.getenv("AZURE_OPENAI_DEPLOYMENT")

        # Keep the original source object that must be updated in-place.
        self.rules_source: dict[str, Any] = self.rules

        logger.info(
            "ValidationService initialized. rules=%s, contract_contents=%s, env_path=%s",
            len(self.rules_source.get("rules", [])) if isinstance(self.rules_source, dict) else 0,
            len(self.contract_text.get("contents", [])) if isinstance(self.contract_text, dict) else 0,
            self.config_file_path,
        )

    def _get_openai_client(self) -> Any:
        try:
            from openai import AzureOpenAI
        except ImportError as exc:
            raise RuntimeError(
                "The 'openai' package is not installed. Install dependencies from requirements.txt."
            ) from exc

        if not self.azure_openai_endpoint:
            raise ValueError("Missing AZURE_OPENAI_ENDPOINT in environment")
        if not self.azure_ai_api_key:
            raise ValueError("Missing AZURE_AI_API_KEY (or AZURE_OPENAI_API_KEY) in environment")
        if not self.model_deployment:
            raise ValueError("Missing GPT_4_1_DEPLOYMENT (or AZURE_OPENAI_DEPLOYMENT) in environment")

        logger.info(
            "Creating Azure OpenAI client with endpoint=%s, api_version=%s, deployment=%s",
            self.azure_openai_endpoint,
            self.azure_openai_api_version,
            self.model_deployment,
        )
        return AzureOpenAI(
            api_key=self.azure_ai_api_key,
            azure_endpoint=self.azure_openai_endpoint,
            api_version=self.azure_openai_api_version,
            timeout=self.DEFAULT_OPENAI_TIMEOUT_SECONDS,
        )

    @staticmethod
    def _parse_json_response(text: str) -> dict[str, Any]:
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            # Attempt to parse the first JSON object if model wrapped content unexpectedly.
            match = re.search(r"\{.*\}", text, flags=re.DOTALL)
            if not match:
                raise
            return json.loads(match.group(0))

    @staticmethod
    def _is_retryable_error(exc: Exception) -> bool:
        message = str(exc).lower()
        retryable_markers = ["429", "500", "502", "503", "504", "timeout", "temporar", "connection"]
        return any(marker in message for marker in retryable_markers)

    @staticmethod
    def _build_openai_error(exc: Exception) -> RuntimeError:
        return RuntimeError(f"Azure OpenAI validation failed: {exc}")

    @staticmethod
    def _normalize_whitespace(value: str) -> str:
        return re.sub(r"\s+", " ", value).strip()

    @staticmethod
    def _extract_field_values(contract_text: dict[str, Any]) -> dict[str, Any]:
        extracted: dict[str, Any] = {}
        contents = contract_text.get("result", {}).get("contents", [])
        if not contents:
            return extracted

        fields = contents[0].get("fields", {})
        for field_name, field_data in fields.items():
            if not isinstance(field_data, dict):
                continue

            if "valueString" in field_data:
                extracted[field_name] = field_data.get("valueString")
            elif "valueArray" in field_data:
                extracted[field_name] = field_data.get("valueArray")
            elif "valueNumber" in field_data:
                extracted[field_name] = field_data.get("valueNumber")
            elif "valueObject" in field_data:
                extracted[field_name] = field_data.get("valueObject")
            elif "valueBoolean" in field_data:
                extracted[field_name] = field_data.get("valueBoolean")
            elif "valueDate" in field_data:
                extracted[field_name] = field_data.get("valueDate")

        return extracted

    @staticmethod
    def _extract_rule_focus(rule: dict[str, Any]) -> str:
        text = f"{rule.get('name', '')} {rule.get('description', '')}".lower()
        tokens = re.findall(r"[a-z0-9_]+", text)
        unique_tokens = []
        for token in tokens:
            if len(token) <= 2:
                continue
            if token in unique_tokens:
                continue
            unique_tokens.append(token)
        return " ".join(unique_tokens[:20])

    def _request_validation_results(self, prompt_payload: dict[str, Any]) -> dict[str, dict[str, str]]:
        client = self._get_openai_client()
        system_prompt = (
            "You validate the contract rules using only the provided contract_evidence. "
            "contract_evidence is a dictionary containing extracted fields from filled contract document with field name/title as key and filled information as value."
            "For every rule in rules list, check and validate against all the contract_evidence key, value i.e field name/title as key and filled information as value and return PASS if rule clearly satisfied else FAIL. "
            "If FAIL, recommendation must be concrete and actionable. "
            "If PASS, set the `recommendation` field to 'Rule satisfied'. "
            "Return strict JSON with this shape: "
            "{\"rules\": [{\"id\": \"001\", \"validation_status\": \"PASS\", \"recommendation\": \"\"}]}"
        )

        last_error: Exception | None = None
        logger.info("System prompt for validation: %s", system_prompt)
        logger.info("Requesting validation results for rules: \n%s", prompt_payload.get("rules", []))
        logger.info("Contract_text: \n%s", prompt_payload.get("contract_fields", {}))
        for attempt in range(3):
            try:
                logger.info("Sending validation request to Azure OpenAI. Attempt=%s", attempt + 1)
                response = client.chat.completions.create(
                    model=self.model_deployment,
                    temperature=0,
                    response_format={"type": "json_object"},
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": json.dumps(prompt_payload, ensure_ascii=True)},
                    ],
                )
                message_content = response.choices[0].message.content or "{}"
                parsed_response = self._parse_json_response(message_content)

                statuses: dict[str, dict[str, str]] = {}
                for item in parsed_response.get("rules", []):
                    rule_id = item.get("id")
                    status = str(item.get("validation_status", "")).upper()
                    recommendation = str(item.get("recommendation", "")).strip()
                    if rule_id and status in {"PASS", "FAIL"}:
                        statuses[rule_id] = {
                            "validation_status": status,
                            "recommendation": recommendation if status == "FAIL" else "Rule satisfied",
                        }

                if not statuses:
                    raise ValueError("Azure OpenAI returned an empty validation result set")

                logger.info("Received validation results for %s rule(s)", len(statuses))
                return statuses
            except Exception as exc:
                last_error = exc
                if not self._is_retryable_error(exc) or attempt == 2:
                    break
                sleep_seconds = 2 ** attempt
                logger.warning(
                    "Azure OpenAI validation attempt %s failed: %s. Retrying in %s second(s).",
                    attempt + 1,
                    exc,
                    sleep_seconds,
                )
                time.sleep(sleep_seconds)

        raise self._build_openai_error(last_error or RuntimeError("Unknown Azure OpenAI error")) from last_error

    def validate(self) -> dict[str, Any]:
        logger.info("Starting contract validation")

        if not isinstance(self.rules_source, dict):
            logger.error("rules source is not a dictionary")
            self.rules_source = {"rules": []}

        rules_list = self.rules_source.get("rules", [])
        if not isinstance(rules_list, list):
            logger.error("rules source has invalid 'rules' type: %s", type(rules_list))
            self.rules_source["rules"] = []
            self.rules = self.rules_source
            return self.rules

        extracted_fields = self._extract_field_values(self.contract_text)

        logger.info(
            "Prepared contract evidence. extracted_fields=%s",
            len(extracted_fields),
        )

        prompt_payload = {
            "instructions": "Evaluate each rule against the `contract_fields` only.",
            "rules": [
                {
                    "id": rule.get("id"),
                    "name": rule.get("name"),
                    "description": rule.get("description"),
                    "focus": self._extract_rule_focus(rule),
                }
                for rule in rules_list
                if isinstance(rule, dict) and rule.get("enabled", True)
            ],
            "contract_fields": extracted_fields,
        }

        llm_results: dict[str, dict[str, str]] = {}
        try:
            llm_results = self._request_validation_results(prompt_payload)
        except Exception as exc:
            logger.exception(
                "LLM validation unavailable, applying local fallback validation only. reason=%s",
                exc,
            )

        for idx, rule in enumerate(rules_list):
            if not isinstance(rule, dict):
                logger.warning("Skipping non-dict rule at index=%s", idx)
                continue

            rule_id = str(rule.get("id", "")).strip()
            if not rule.get("enabled", True):
                logger.info("Skipping disabled rule id=%s", rule_id)
                continue

            result = llm_results.get(rule_id)
            if result:
                validation_status = result.get("validation_status", "FAIL")
                recommendation = result.get("recommendation", "") if validation_status == "FAIL" else "Rule satisfied"
                logger.info("Rule id=%s validated by LLM with status=%s", rule_id, validation_status)
            else:
                logger.error("No LLM result for rule id=%s, marking as FAIL")
                validation_status = "FAIL"
                recommendation = "LLM validation failed or unavailable. Please review the rule against the contract manually."

            rule["validation_status"] = validation_status
            rule["recommendation"] = recommendation if validation_status == "FAIL" else "Rule satisfied"

        self.rules = self.rules_source
        logger.info("Validation completed. total_rules=%s", len(self.rules_source.get("rules", [])))
        return self.rules
    





























# rules = { 'rules': [ { 'description': 'Description of Service or Contract Works must '
#                               'contain actual service description, not just '
#                               'placeholder instructions usually found in '
#                               'Section 3',
#                'enabled': True,
#                'id': 'SPN-001',
#                'name': 'Service Description Filled',
#                'recommendation': '',
#                'severity': 'P1',
#                'validation_status': 'UNKNOWN'},
#              { 'description': 'The Novartis legal entity name must be '
#                               'explicitly stated — not the placeholder like '
#                               '[INSERT NOVARTIS ENTITY]',
#                'enabled': True,
#                'id': 'SPN-002',
#                'name': 'Novartis Entity Name Filled',
#                'recommendation': '',
#                'severity': 'P1',
#                'validation_status': 'UNKNOWN'},
#              { 'description': 'The supplier legal entity name must be '
#                               'explicitly stated — not a placeholder',
#                'enabled': True,
#                'id': 'SPN-003',
#                'name': 'Supplier Entity Name Filled',
#                'recommendation': '',
#                'severity': 'P1',
#                'validation_status': 'UNKNOWN'},
#              { 'description': 'Statement of Work Startd date must be present — '
#                               'not left blank, usually found in Section 6.',
#                'enabled': True,
#                'id': 'SPN-004',
#                'name': 'Statement of Work Start Date',
#                'recommendation': '',
#                'severity': 'P1',
#                'validation_status': 'UNKNOWN'},
#              { 'description': 'Statement of Work Expiry date must be present — '
#                               'not left blank, usually found in Section 6.',
#                'enabled': True,
#                'id': 'SPN-005',
#                'name': 'Statement of Work Expiry Date',
#                'recommendation': '',
#                'severity': 'P1',
#                'validation_status': 'UNKNOWN'},
#              { 'description': 'must include assumptions and obligations of '
#                               'Novartis — not left blank, usually found in '
#                               'Section 15.',
#                'enabled': True,
#                'id': 'SPN-006',
#                'name': 'Assumptions And Novartis Obligations',
#                'recommendation': '',
#                'severity': 'P1',
#                'validation_status': 'UNKNOWN'}],
#   'schema_id': 'SPIN_SOW',
#   'version': '1.0.0'}


# import json
# data_dict = None
# # Use a 'with' statement for proper file handling
# with open('/Users/zeeshan_ashraf/nova/intel/contract-intel/app/data/extracted/analysis_result_20260322_233016.json', 'r') as file_object:
#     data_dict = json.load(file_object)

# validationService: ValidationService = ValidationService(rules=rules, contract_text=data_dict)
# results = validationService.validate() #returns the same rule with updated keys: validation_status & recommendation
# print(json.dumps(results, indent=2))