from datetime import datetime
import logging
import json
import time
import os
import sys
import asyncio
from typing import Any, Dict, Optional
from aiohttp import client
from dotenv import find_dotenv, load_dotenv

from app.services.utils.content_understanding_client import AzureContentUnderstandingClient
from app.services.utils.extension.document_processor import DocumentProcessor
from app.services.utils.extension.sample_helper import save_json_to_file 
from azure.identity import DefaultAzureCredential


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ContentExtractionService:
    def __init__(self, config_file_path: str = "app/config/.env", analyzer_template_file: str = "app/data/analyzer/sow_analyzer_v1.json", analyzer_result_dir: str = "app/data/output"):

        self.API_KEY_ENV_FILE_PATH = config_file_path
        self.ANALYZER_TEMPLATE_FILE = analyzer_template_file
        self.ANALYZER_RESULT_DIR = analyzer_result_dir
        load_dotenv(self.API_KEY_ENV_FILE_PATH)

        # For authentication, you can use either token-based auth or subscription key; only one is required
        self.AZURE_AI_ENDPOINT = os.getenv("AZURE_AI_ENDPOINT")
        # IMPORTANT: Replace with your actual subscription key or set it in your ".env" file if not using token authentication
        self.AZURE_AI_API_KEY = os.getenv("AZURE_AI_API_KEY")
        self.API_VERSION = "2025-11-01"
        # Get model deployment names from environment variables
        self.GPT_4_1_DEPLOYMENT = os.getenv("GPT_4_1_DEPLOYMENT")
        self.GPT_4_1_MINI_DEPLOYMENT = os.getenv("GPT_4_1_MINI_DEPLOYMENT")
        self.TEXT_EMBEDDING_3_LARGE_DEPLOYMENT = os.getenv("TEXT_EMBEDDING_3_LARGE_DEPLOYMENT")

        logger.info(f"Using API Keys from: {self.API_KEY_ENV_FILE_PATH}")
        logger.info(f"AZURE_AI_ENDPOINT: {self.AZURE_AI_ENDPOINT}")
        logger.info(f"API_VERSION: {self.API_VERSION}")
        logger.info(f"GPT_4_1_DEPLOYMENT: {self.GPT_4_1_DEPLOYMENT}")
        logger.info(f"GPT_4_1_MINI_DEPLOYMENT: {self.GPT_4_1_MINI_DEPLOYMENT}")
        logger.info(f"TEXT_EMBEDDING_3_LARGE_DEPLOYMENT: {self.TEXT_EMBEDDING_3_LARGE_DEPLOYMENT}")


    # Create token provider for Azure AD authentication
    def __token_provider(self) -> str:
        credential = DefaultAzureCredential()
        token = credential.get_token("https://cognitiveservices.azure.com/.default")
        return token.token

    # Create the Content Understanding client
    def __get_content_understanding_client(self):
        client: AzureContentUnderstandingClient = None
        try:
            client = AzureContentUnderstandingClient(
                endpoint=self.AZURE_AI_ENDPOINT,
                api_version=self.API_VERSION,
                subscription_key=self.AZURE_AI_API_KEY,
                token_provider=self.__token_provider if not self.AZURE_AI_API_KEY else None,
                x_ms_useragent="azure-ai-content-understanding-python-sample-ga"    # The user agent is used for tracking sample usage and does not provide identity information. You can change this if you want to opt out of tracking.
            )
            credential_type = "Subscription Key" if self.AZURE_AI_API_KEY else "Azure AD Token"
            logger.info(f"✅ Client created successfully")
            logger.info(f"   Endpoint: {self.AZURE_AI_ENDPOINT}")
            logger.info(f"   Credential: {credential_type}")
            logger.info(f"   API Version: {self.API_VERSION}")
        except Exception as e:
            credential_type = "Subscription Key" if self.AZURE_AI_API_KEY else "Azure AD Token"
            logger.error(f"❌ Failed to create client")
            logger.error(f"   Endpoint: {self.AZURE_AI_ENDPOINT}")
            logger.error(f"   API Version: {self.API_VERSION}")
            logger.error(f"   Credential: {credential_type}")
            logger.error(f"   Error: {e}")
            raise

        try:
            processor = DocumentProcessor(client)
            logger.info(f"✅ DocumentProcessor created successfully")
        except Exception as e:
            logger.error(f"❌ Failed to create DocumentProcessor: {e}")
            raise
        return client



    def __validate_model_deployment(self, client: AzureContentUnderstandingClient):
        # Check if required deployments are configured
        missing_deployments = []
        if not self.GPT_4_1_DEPLOYMENT:
            missing_deployments.append("GPT_4_1_DEPLOYMENT")
        if not self.GPT_4_1_MINI_DEPLOYMENT:
            missing_deployments.append("GPT_4_1_MINI_DEPLOYMENT")
        if not self.TEXT_EMBEDDING_3_LARGE_DEPLOYMENT:
            missing_deployments.append("TEXT_EMBEDDING_3_LARGE_DEPLOYMENT")

        if missing_deployments:
            logger.warning(f"⚠️  Warning: Missing required model deployment configuration(s):")
            for deployment in missing_deployments:
                logger.warning(f"   - {deployment}")
            logger.warning("\n   Prebuilt analyzers require GPT-4.1, GPT-4.1-mini, and text-embedding-3-large deployments.")
            logger.warning("   Please:")
            logger.warning("   1. Deploy all three models in Azure AI Foundry")
            logger.warning("   2. Add the following to notebooks/.env:")
            logger.warning("      GPT_4_1_DEPLOYMENT=<your-gpt-4.1-deployment-name>")
            logger.warning("      GPT_4_1_MINI_DEPLOYMENT=<your-gpt-4.1-mini-deployment-name>")
            logger.warning("      TEXT_EMBEDDING_3_LARGE_DEPLOYMENT=<your-text-embedding-3-large-deployment-name>")
            logger.warning("   3. Restart the kernel and run this cell again")
        else:
            logger.info(f"📋 Configuring default model deployments...")
            logger.info(f"   GPT-4.1 deployment: {self.GPT_4_1_DEPLOYMENT}")
            logger.info(f"   GPT-4.1-mini deployment: {self.GPT_4_1_MINI_DEPLOYMENT}")
            logger.info(f"   text-embedding-3-large deployment: {self.TEXT_EMBEDDING_3_LARGE_DEPLOYMENT}")

            try:
                # Update defaults to map model names to your deployments
                result = client.update_defaults({
                    "gpt-4.1": self.GPT_4_1_DEPLOYMENT,
                    "gpt-4.1-mini": self.GPT_4_1_MINI_DEPLOYMENT,
                    "text-embedding-3-large": self.TEXT_EMBEDDING_3_LARGE_DEPLOYMENT
                })
                
                logger.info(f"✅ Default model deployments configured successfully")
                logger.info(f"   Model mappings:")
                for model, deployment in result.get("modelDeployments", {}).items():
                    logger.info(f"     {model} → {deployment}")
            except Exception as e:
                logger.error(f"❌ Failed to configure defaults: {e}")
                logger.warning(f"   This may happen if:")
                logger.warning(f"   - One or more deployment names don't exist in your Azure AI Foundry project")
                logger.warning(f"   - You don't have permission to update defaults")
                raise

    # client = get_content_understanding_client()
    # logger.info("\n✅ Client is ready to use" + str(client))
    # logger.info("\n🔍 Validating model deployments...")
    # self.__validate_model_deployment(client)

    '''
    Creates a custom analyzer on Azure AI Content Understanding using a predefined template saved at self.ANALYZER_TEMPLATE_FILE.
    The template defines the structure and fields to be extracted from the document.
    Returns the ID of the created analyzer.
    '''
    def __create_custom_analyzer(self, client: AzureContentUnderstandingClient) -> str:
        analyzer_id = f"sow_key_extraction_{int(time.time())}"

        invoice_analyzer: Dict[str, Any] = None
        with open(self.ANALYZER_TEMPLATE_FILE, 'r') as file:
            invoice_analyzer = json.load(file)

        logger.info(f"{json.dumps(invoice_analyzer, indent=2)}")
        # Start the analyzer creation operation
        response = client.begin_create_analyzer(
            analyzer_id=analyzer_id,
            analyzer_template=invoice_analyzer,
        )

        # Wait for the analyzer to be created
        logger.info(f"⏳ Waiting for analyzer creation to complete...")
        client.poll_result(response)
        logger.info(f"✅ Analyzer '{analyzer_id}' created successfully!")
        return analyzer_id



    '''
    Executes the custom analyzer on a specified document on Content Understanding and returns the analysis results.
    '''
    def __execute_custom_analyzer(self, client: AzureContentUnderstandingClient, analyzer_id: str, document_path: str) -> Dict[str, Any]:

        # Begin document analysis operation
        print(f"🔍 Starting document analysis with analyzer '{analyzer_id}'...")
        analysis_response: Dict[str, Any] = client.begin_analyze_binary(
            analyzer_id=analyzer_id,
            file_location=document_path,
        )

        # Wait for analysis completion
        print(f"⏳ Waiting for document analysis to complete...")
        analysis_result = client.poll_result(analysis_response)
        print(f"✅ Document analysis completed successfully!")
        return analysis_result


    def pretty_print_analysis_result(self, analysis_result: Dict[str, Any]) -> None:
        # Display comprehensive results
        if analysis_result and "result" in analysis_result:
            result = analysis_result["result"]
            contents = result.get("contents", [])
            
            if contents:
                first_content = contents[0]
                
                # Display extracted fields
                fields = first_content.get("fields", {})
                print("📊 Extracted Fields:")
                print("-" * 80)
                if fields:
                    for field_name, field_value in fields.items():
                        field_type = field_value.get("type")
                        if field_type == "string":
                            print(f"{field_name}: {field_value.get('valueString')}")
                        elif field_type == "number":
                            print(f"{field_name}: {field_value.get('valueNumber')}")
                        elif field_type == "array":
                            print(f"{field_name} (array with {len(field_value.get('valueArray', []))} items):")
                            for idx, item in enumerate(field_value.get('valueArray', []), 1):
                                if item.get('type') == 'object':
                                    print(f"  Item {idx}:")
                                    for key, val in item.get('valueObject', {}).items():
                                        if val.get('type') == 'string':
                                            print(f"    {key}: {val.get('valueString')}")
                                        elif val.get('type') == 'number':
                                            print(f"    {key}: {val.get('valueNumber')}")
                        elif field_type == "object":
                            print(f"{field_name}: {field_value.get('valueObject')}")
                        print()
                else:
                    logger.warning("No fields extracted")
                print()
                
                # Display content metadata
                print("📋 Content Metadata:")
                print("-" * 80)
                print(f"Kind: {first_content.get('kind')}")
                print(f"Pages: {first_content.get('startPageNumber')} - {first_content.get('endPageNumber')}")
                print(f"Unit: {first_content.get('unit')}")
                print()
        return

    
    
    '''
    Saves the full results to a JSON file for further inspection & returns the JSON file path.

    Results from the analyzer can be complex and may contain various types of extracted data, metadata, and confidence scores. 
    This function provides a structured way to display the key information in a human-readable format, 
    while also saving the full results to a JSON file for further inspection if needed.
    '''
    def save_analysis_result(self, analysis_result: Dict[str, Any]) -> str:
        output_file = ""
        if analysis_result:            
            # Save full result to file
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_file = f"{self.ANALYZER_RESULT_DIR}/analysis_result_{timestamp}.json"
            os.makedirs(self.ANALYZER_RESULT_DIR, exist_ok=True)
            
            with open(output_file, 'w') as f:
                json.dump(analysis_result, f, indent=2)
            
            print(f"💾 Full analysis result saved to: {output_file}")
        else:
            logger.warning("No analysis result available")
        return output_file



    def delete_custom_analyzer(self, client: AzureContentUnderstandingClient, analyzer_id: str):
        try:
            client.delete_analyzer(analyzer_id)
            logger.info(f"✅ Analyzer '{analyzer_id}' ⛔️ deleted successfully!")
        except Exception as e:
            logger.error(f"❌ Failed to delete analyzer '{analyzer_id}': {e}")


    def run_analysis(self, document_path: str) -> Optional[Dict[str, Any]]:
        try:
            logger.info("\n🔍 Initializing client...")
            client = self.__get_content_understanding_client()
            logger.info("\n✅ Client is ready to use" + str(client))
            
            logger.info("\n🔍 Validating model deployments...")
            self.__validate_model_deployment(client)
            logger.info("\n✅ Model deployments validated successfully!")
            
            logger.info("\n🔍 Creating custom analyzer...")
            analyzer_id = self.__create_custom_analyzer(client)
            logger.info("\n✅ Custom analyzer created successfully!")

            logger.info("\n🔍 Executing custom analyzer...")
            analysis_result: Dict[str, Any] = self.__execute_custom_analyzer(client, analyzer_id, document_path)
            logger.info("\n✅ Custom analyzer executed successfully!")
            
            self.pretty_print_analysis_result(analysis_result)
            output_file = self.save_analysis_result(analysis_result)
            logger.info(f"\n✅ Analysis complete. Results saved to: {output_file}")
        except Exception as e:
            logger.error(f"❌ Error during analysis: {e}")
            return None
        finally:
            if 'client' in locals() and 'analyzer_id' in locals():
                self.delete_custom_analyzer(client, analyzer_id)
                logger.info(f"🧹 ⛔️⛔️⛔️Cleaned up resources.⛔️⛔️⛔️")

        return analysis_result, output_file


contentExtractionService = ContentExtractionService()
print("\n✅ ContentExtractionService initialized and ready to use.")
print(contentExtractionService.AZURE_AI_ENDPOINT)