import http.server
import socketserver
import os

PORT = 8080
# Optionally, set a specific directory to serve files from
# web_dir = os.path.join(os.path.dirname(__file__), 'web')
# os.chdir(web_dir) # Uncomment to change the working directory

Handler = http.server.SimpleHTTPRequestHandler

with socketserver.TCPServer(("", PORT), Handler) as httpd:
    print(f"Serving at port {PORT}")
    httpd.serve_forever()
