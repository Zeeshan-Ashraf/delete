STAGING_PATH = 'app/data/staging'
DEFAULT_RULES_FILE = 'app/data/rules/spin_sow_rules.json'