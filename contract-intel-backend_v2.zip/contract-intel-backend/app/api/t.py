from pathlib import Path
BASE_DIR = Path(__file__).parent.parent
EXTRACTED_DIR = BASE_DIR / "data" / "extracted"
print(BASE_DIR)
print(EXTRACTED_DIR)