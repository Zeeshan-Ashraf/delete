from typing import Any, Dict

from fastapi import FastAPI, UploadFile, File, Request, Query
from fastapi.params import Form
from fastapi.responses import FileResponse, JSONResponse
from pathlib import Path
import json
import logging
from fastapi import APIRouter
from fastapi.middleware.cors import CORSMiddleware

from app.services.content_extraction_engine.content_extraction_service import ContentExtractionService
from app.services.validation_engine.validation_service import ValidationService

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("contract-intel")

# Define base directory and extracted directory
BASE_DIR = Path(__file__).parent.parent
EXTRACTED_DIR = BASE_DIR / "data" / "extracted"
EXTRACTED_DIR.mkdir(parents=True, exist_ok=True)

app: FastAPI = FastAPI()
router_v1 = APIRouter(prefix="/v1")
origins = [
    "http://localhost",
    "http://localhost:8000",
    "http://127.0.0.1:8000",
    # Add other allowed origins as needed
    "http://localhost:8080",
    "http://127.0.0.1:8080",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@router_v1.get("/index.html")
async def get_index():
    index_file = BASE_DIR / "ui" / "index.html"
    logger.info(f"Serving index.html from {index_file}")
    if index_file.exists():
        return FileResponse(index_file)
    logger.warning("index.html not found")
    return JSONResponse(content={"error": "index.html not found"}, status_code=404)

@router_v1.get("/rule/{id}")
async def get_rule(id: str):
    logger.info(f"Fetching rule with id: {id}")
    return {
      "rules": [
          {
              "id": "001",
              "name": "Contractual Framework Option",
              "description": "Selected contractual framework option (1, 2, or 3), Must select Option 1, 2, or 3",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "002",
              "name": "SOX Relevance",
              "description": "Whether Supplier’s IT systems involve SOX-relevant systems, Per Clause 27.6(f)",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "003",
              "name": "Asset List",
              "description": "List of assets to be used in service/works delivery, By class or specific assets; include additional info if required",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "004",
              "name": "Additional Asset Information",
              "description": "Any extra asset details required by Novartis, If applicable",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "005",
              "name": "Outages Process",
              "description": "Process for agreeing and managing outages, Insert process and parameters",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "006",
              "name": "Novartis Dependencies",
              "description": "List of Novartis dependencies for the SOW, Only items in Novartis’ control",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "007",
              "name": "Operation Procedures & Work Instructions",
              "description": "List of procedures and instructions to be provided, Specify topics and timelines",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "008",
              "name": "Additional Business Continuity/DR Provisions",
              "description": "Any extra requirements beyond Framework Agreement, If applicable",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "009",
              "name": "Additional Policies & Standards",
              "description": "Any additional policies Supplier must comply with, Not already in Schedule 9",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "010",
              "name": "P3 Policy Compliance",
              "description": "Confirmation of compliance with P3 Policy, If interacting with HCPs, patients, etc.",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "011",
              "name": "Pharmacovigilance Obligations",
              "description": "Compliance with vigilance reporting and procedures, See Paragraph 24.2 and Appendices 3/4",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "012",
              "name": "Additional Exit Services",
              "description": "Details of additional exit/termination services, If required",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "013",
              "name": "Data Processing Details",
              "description": "Subject-matter, duration, nature, type of data, data subjects, retention period, See Section 26; all fields to be completed",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "014",
              "name": "Data Separation",
              "description": "Circumstances where data separation is not required, If applicable",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "015",
              "name": "Data Back-up",
              "description": "Whether Supplier is responsible for data backup, If not, must be stated",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "016",
              "name": "Confidential Information in Contract Works",
              "description": "Identify if any works may include confidential info, If applicable",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "017",
              "name": "Charges",
              "description": "Charging mechanism (T&M, fixed price, other) and amounts, Refer to Appendix 2 (PCC); specify currency and payment schedule",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "018",
              "name": "Pricing Model",
              "description": "Pricing model: Fixed Price or Time & Material, Must be clearly indicated",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "019",
              "name": "Invoicing Schedule",
              "description": "When invoices are to be issued, If different from standard terms",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "020",
              "name": "Invoicing Currency",
              "description": "Currency for invoices, If different from default",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "021",
              "name": "Project Cost Calculator (PCC)",
              "description": "Project Cost Calculator attached as Appendix 2, Must be attached and referenced",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "022",
              "name": "PCC Timeline Alignment",
              "description": "PCC effective/expiry dates match SOW dates, Manual cross-check needed",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "023",
              "name": "Timesheet Submission",
              "description": "Timesheet requirements for Supplier personnel, Specify tool and deadlines",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "024",
              "name": "Statement of Work Effective Date",
              "description": "Date the SOW becomes effective, Insert date",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "025",
              "name": "Statement of Work Expiry Date",
              "description": "Date the SOW expires, Insert date; specify renewal/extension if applicable",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "026",
              "name": "Renewal/Extension Details",
              "description": "Details of any renewal or extension periods, If applicable",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "027",
              "name": "Services Commencement Date",
              "description": "Date services/works are to commence, Insert date",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "028",
              "name": "Service Commencement Date (GxP)",
              "description": "Date of commencement for each GxP service, If applicable",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "029",
              "name": "Supplier Locations",
              "description": "Locations from which services/works will be delivered, List all relevant locations",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "030",
              "name": "Service Delivery Locations",
              "description": "Novartis/other sites where services will be provided, List all relevant locations",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "031",
              "name": "Milestones",
              "description": "List of milestones, descriptions, due dates, and criticality, Table to be completed for each milestone",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "032",
              "name": "Milestone Names",
              "description": "Name for each milestone, Each milestone must have a name",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "033",
              "name": "Milestone Due Dates",
              "description": "Due date for each milestone, Each milestone must have a due date",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "034",
              "name": "Acceptance Criteria",
              "description": "Acceptance criteria for each milestone, Must be defined in Appendix 1 or Section 6.7",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "035",
              "name": "Hypercare Services",
              "description": "Details of post-acceptance support, Insert period (days), specific services, etc.",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "036",
              "name": "Hypercare Period",
              "description": "Duration of hypercare in days, Must specify number of days",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "037",
              "name": "Assigned Contracts",
              "description": "List of assigned contracts relevant to the SOW, If any",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "038",
              "name": "Managed Contracts",
              "description": "List of managed contracts relevant to the SOW, If any",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "039",
              "name": "Named Resources & Roles",
              "description": "List of named Supplier personnel and their roles, To be included in PCC",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "040",
              "name": "Personnel Capabilities",
              "description": "Technical capabilities required for Supplier personnel, List required skills/qualifications",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "041",
              "name": "Key Personnel",
              "description": "List of key personnel for the SOW, Identify in PCC",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "042",
              "name": "Staffing Implementation Plan",
              "description": "Provisions for staffing plan, If required",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "043",
              "name": "Background Check Process",
              "description": "Details if different/more rigorous than standard, If required",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "044",
              "name": "Quality Agreement",
              "description": "Whether a Quality Agreement applies, Confirm with Novartis Quality Team; Yes/No must be selected",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "045",
              "name": "GxP Services",
              "description": "List of GxP services subject to Quality Agreement, If applicable",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "046",
              "name": "Applicable Quality Management System",
              "description": "Which QMS applies (Supplier or Novartis), If applicable",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "047",
              "name": "Additional Quality Requirements",
              "description": "Any extra requirements for quality, If applicable",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "048",
              "name": "Description of Service(s)",
              "description": "Detailed description and scope of the services to be provided, Should include volumes, specs, critical services",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "049",
              "name": "Description of Contract Works",
              "description": "List and description of Contract Works to be delivered, Identify which are Critical Services",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "050",
              "name": "Service Recipients",
              "description": "List of entities receiving the service, May include Novartis, Affiliates, etc.",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "051",
              "name": "Tools to be Used",
              "description": "List of Novartis tools to be used by Supplier, Specify tools required for delivery",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "052",
              "name": "Processes to be Followed",
              "description": "List of processes Supplier must follow, Specify or refer to SOPs/Operations Manual",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "053",
              "name": "Source Code Escrow",
              "description": "Whether source code is to be placed in escrow and cost allocation, If applicable",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "054",
              "name": "Approved Subcontractors",
              "description": "List of approved subcontractors, Include any exceptions/alternative arrangements",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "055",
              "name": "Supplier Entity Name",
              "description": "Full legal name of the Supplier, Must be filled, not left as placeholder",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "056",
              "name": "Supplier Registered Number",
              "description": "Supplier's company registration number, Required for identification",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "057",
              "name": "Supplier Registered Office Address",
              "description": "Supplier's registered office address, Required for identification",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "058",
              "name": "Novartis Entity Name",
              "description": "Full legal name of Novartis party, Must be filled, not left as placeholder",
              "severity": "P1",
              "enabled": True
          },
          {
              "id": "059",
              "name": "Signatory Details",
              "description": "Name, title, date, and place for Supplier signatory, Required for execution",
              "severity": "P1",
              "enabled": True
          }
      ]
    }

@router_v1.post("/rule")
async def post_rule(request: Request):
    payload = await request.json()
    logger.info(f"Received rule payload: {payload}")
    return JSONResponse(content=payload)


@router_v1.post("/extract")
async def post_extract(file: UploadFile = File(...)):
    file_path = EXTRACTED_DIR / file.filename
    logger.info(f"Saving uploaded file to {file_path}")
    with file_path.open("wb") as f:
        content = await file.read()
        f.write(content)
    logger.info(f"{file.filename} File saved: {file_path}")
    return {"filename": file.filename, "saved_to": str(file_path)}


@router_v1.get("/validate")
async def get_validate(ruleID: int = Query(...), extractID: int = Query(...)):
    logger.info(f"Validating ruleID={ruleID}, extractID={extractID}")
    #return {"ruleID": ruleID, "extractID": extractID, "status": "validated"}
    return JSONResponse(content={
      "rules": [
        {
          "description": "lorem ipsum",
          "enabled": True,
          "id": "SPN-001",
          "name": "Service Description Filled",
          "recommendation": "",
          "severity": "P1",
          "validation_status": "PASS"
        },
        {
          "description": "some description",
          "enabled": True,
          "id": "SPN-002",
          "name": "Novartis Entity Name Filled",
          "recommendation": "",
          "severity": "P1",
          "validation_status": "PASS"
        }
      ]
    })


@router_v1.post("/validate")
async def post_validate(file: UploadFile = File(...), rules: str = Form(...)):
    file_path = EXTRACTED_DIR / file.filename
    logger.info(f"Saving uploaded file to {file_path}")
    with file_path.open("wb") as f:
        content = await file.read()
        f.write(content)
    logger.info(f"File saved: {file_path}")
    try:
      parsed_rules = json.loads(rules)
    except json.JSONDecodeError:
      return JSONResponse(content={"error": "Invalid rules JSON"}, status_code=400)
    logger.info(f"Rules JSON: {parsed_rules}")

    #TODO1####################
    #file saved at EXTRACTED_DIR / file.filename
    #extracted_dict = run extractservice with this file
    
    # Initialize the content extraction service
    extraction_service = ContentExtractionService()

    # Analyze the document
    logger.info(f"Running extraction on document: {file_path}, will take some time...")
    analysis_result: Dict[str, Any] = {}
    analysis_result, output_file= extraction_service.run_analysis(file_path)
    logger.info(f"Analysis complete. Results saved to: {output_file}")




    #TODO2#######################
    #run validate service with rules & extracted_dict
    validationService: ValidationService = ValidationService(rules=parsed_rules, contract_text=analysis_result)
    results: Dict[str, Any] = validationService.validate()
    logger.info(f"Validation results:\n {json.dumps(results, indent=2)}")


    return JSONResponse(content=results)

    return JSONResponse(content={
      "rules": [
        {
          "description": "Description of Service or Contract Works must contain actual service description, not just placeholder instructions usually found in Section 3",
          "enabled": True,
          "id": "SPN-001",
          "name": "Service Description Filled",
          "recommendation": "",
          "severity": "P1",
          "validation_status": "PASS"
        },
        {
          "description": "The Novartis legal entity name must be explicitly stated \u2014 not the placeholder like [INSERT NOVARTIS ENTITY]",
          "enabled": True,
          "id": "SPN-002",
          "name": "Novartis Entity Name Filled",
          "recommendation": "",
          "severity": "P1",
          "validation_status": "PASS"
        },
        {
          "description": "The supplier legal entity name must be explicitly stated \u2014 not a placeholder",
          "enabled": True,
          "id": "SPN-003",
          "name": "Supplier Entity Name Filled",
          "recommendation": "",
          "severity": "P1",
          "validation_status": "PASS"
        },
        {
          "description": "Statement of Work Startd date must be present \u2014 not left blank, usually found in Section 6.",
          "enabled": True,
          "id": "SPN-004",
          "name": "Statement of Work Start Date",
          "recommendation": "",
          "severity": "P1",
          "validation_status": "PASS"
        },
        {
          "description": "Statement of Work Expiry date must be present \u2014 not left blank, usually found in Section 6.",
          "enabled": True,
          "id": "SPN-005",
          "name": "Statement of Work Expiry Date",
          "recommendation": "The Statement of Work Expiry Date is currently set as '{Enter Date}', which is a placeholder. Replace this with the actual expiry date.",
          "severity": "P1",
          "validation_status": "FAIL"
        },
        {
          "description": "must include assumptions and obligations of Novartis \u2014 not left blank, usually found in Section 15.",
          "enabled": True,
          "id": "SPN-006",
          "name": "Assumptions And Novartis Obligations",
          "recommendation": "Section 15 (Assumptions & Novartis Obligations) is referenced in the table of contents, but no content from this section is present in the provided evidence. Ensure that Section 15 includes explicit assumptions and obligations of Novartis and is not left blank.",
          "severity": "P1",
          "validation_status": "FAIL"
        }
      ],
      "schema_id": "SPIN_SOW",
      "version": "1.0.0"
    })
'''
INFO:contract-intel:Saving uploaded file to /Users/zeeshan_ashraf/nova/intel/contract-intel-backend/app/data/extracted/web_server.py
INFO:contract-intel:File saved: /Users/zeeshan_ashraf/nova/intel/contract-intel-backend/app/data/extracted/web_server.py
INFO:contract-intel:Rules JSON: {'rules': [{'id': 'SPN-001', 'name': 'Service Description Filled', 'description': 'Section 3 (Description of Service or Contract Works) must contain actual service description, not just placeholder instructions', 'severity': 'Critical', 'enabled': True}, {'id': 'SPN-002', 'name': 'Novartis Entity Name Filled', 'description': 'The Novartis legal entity name must be explicitly stated — not the placeholder [INSERT NOVARTIS ENTITY]', 'severity': 'Critical', 'enabled': True}, {'id': 'SPN-003', 'name': 'Supplier Entity Name Filled', 'description': 'The supplier legal entity name must be explicitly stated — not a placeholder', 'severity': 'Critical', 'enabled': True}, {'id': 'SPN-004', 'name': 'Statement of Work Start Date', 'description': 'Section 6 Statement of Work Startd date must be present — not left blank', 'severity': 'Critical', 'enabled': True}, {'id': 'SPN-005', 'name': 'Statement of Work Expiry Date', 'description': 'Section 6 Statement of Work Expiry date must be present — not left blank', 'severity': 'Critical', 'enabled': True}, {'id': 'SPN-006', 'name': 'Assumptions And Novartis Obligations', 'description': 'Section 15 must include assumptions and obligations of Novartis — not left blank', 'severity': 'Warning', 'enabled': True}]}
'''


app.include_router(router_v1)


# if __name__ == "__main__":
#   import uvicorn
#   logger.info("Starting FastAPI app")
#   # Running this file directly can break reload import resolution for package paths.
#   uvicorn.run(app, host="0.0.0.0", port=8000, reload=False)
#   #run from root directory with command: python app/api/route.py