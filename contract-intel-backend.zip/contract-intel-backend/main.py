import logging
from app.api.route import app
# import json

# from app.services.content_extraction_engine.content_extraction_service import ContentExtractionService
# import logging
# from app.config.data_config import STAGING_PATH, DEFAULT_RULES_FILE
# from pathlib import Path
# from app.services.validation_engine.validation_service import ValidationService

logger = logging.getLogger(__name__)


# if __name__ == "__main__":
#     # Initialize the content extraction service
#     extraction_service = ContentExtractionService()

#     # Path to the document to analyze
#     document_path = "app/data/2.pdf" # Update this path to your document

#     # Analyze the document
#     output_file = extraction_service.run_analysis(document_path)
#     logger.info(f"Analysis complete. Results saved to: {output_file}")







    
#     RULES_FILE_PATH = "/Users/zeeshan_ashraf/nova/intel/contract-intel/app/data/rules/" + Path(DEFAULT_RULES_FILE).name
#     logger.info(f"Using rules file: {RULES_FILE_PATH}")

#     CONTRACT_FILE_PATH = "/Users/zeeshan_ashraf/nova/intel/contract-intel/app/data/output/" + Path(output_file).name
#     logger.info(f"Using contract file: {CONTRACT_FILE_PATH}")

#     validationService: ValidationService = ValidationService(rules=RULES_FILE_PATH, contract_text=CONTRACT_FILE_PATH)
#     dd = validationService.validate()

#     print(json.dumps(dd, indent=2))

if __name__ == "__main__":
    import uvicorn
    logger.info("Starting FastAPI app")
    uvicorn.run("app.api.route:app", host="0.0.0.0", port=8000, reload=True)
